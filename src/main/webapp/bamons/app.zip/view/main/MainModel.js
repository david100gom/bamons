Ext.define('SpringBatch.view.main.MainModel', {
    extend: 'Ext.app.ViewModel',

    alias: 'viewmodel.main',

    data: {
        name: '배치 모니터링'
    }

});